/*
 * Copyright 2012 SIB Visions GmbH
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 *
 *
 * History
 *
 * 28.12.2012 - [JR] - creation
 */
package com.sibvisions.vertx;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Hashtable;

import javax.rad.server.ISession;
import javax.rad.server.InjectObject;
import javax.rad.server.event.ISessionListener;

import org.vertx.java.core.Handler;
import org.vertx.java.core.Vertx;
import org.vertx.java.core.buffer.Buffer;
import org.vertx.java.core.net.NetServer;
import org.vertx.java.core.net.NetSocket;

import com.sibvisions.rad.server.AbstractSession;
import com.sibvisions.rad.server.IRequest;
import com.sibvisions.rad.server.IResponse;
import com.sibvisions.rad.server.Server;

/**
 * The <code>NetSocketServer</code> uses {@link Server} and offers a lightweight socket server based
 * on {@link org.vertx.java.core.net.NetServer}.
 * 
 * @author Ren� Jahn
 */
public class NetSocketServer implements ISessionListener
{
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	// Class members
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	/** the vert.x instance. */
	private Vertx vertx;
	
	/** the vertx http server. */
	private NetServer srvVertx;
	
	/** the JVx server. */
	private Server srvJVx;

	/** the injection object for our vert.x instance. */
	private InjectObject ijoVertx;
	
	/** the cluster hostname or ip. */
	private String sClusterHost = null;

	/** the cluster port. */
	private int iClusterPort = -1;
	
	/** the http port. */
	private int iPort = 8888;
	
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	// Initialization
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	/**
	 * Starts a standalone netsocket server.
	 * 
	 * @param pArgs startup arguments
	 */	
	public static void main(String[] pArgs)
	{
		Hashtable<String, String> htParams = Util.parseCommandLineProperties(pArgs);
		
		int iPort;
		
		try
		{
			iPort = Integer.parseInt(htParams.get("cluster-port"));
		}
		catch (Exception e)
		{
			iPort = -1;
		}
		
		NetSocketServer srv = new NetSocketServer();
		srv.setClusterHost(htParams.get("cluster-host"));

		if (iPort > 0)
		{
			srv.setClusterPort(iPort);
		}
		srv.start();
				
		synchronized(srv)
		{
			try
			{
				srv.wait();
			}
			catch (Exception e)
			{
				//nothing to be done
			}
		}
	}
	
	/**
	 * Creates a new instance of <code>NetSocketServer</code> without clustering.
	 */
	public NetSocketServer()
	{
		this(null);
	}
	
	/**
	 * Creates a new instance of <code>NetSocketServer</code> with the given Vertx instance.
	 * 
	 * @param pVertx the Vertx instance
	 */	
	public NetSocketServer(Vertx pVertx)
	{
		srvJVx = new Server();
		srvJVx.getSessionManager().addSessionListener(this);
		
		vertx = pVertx;
	}

	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	// Interface implementation
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~	

	/**
	 * {@inheritDoc}
	 */
	public void sessionCreated(ISession pSession)
	{
		if (ijoVertx == null)
		{
			ijoVertx = new InjectObject("vertx", vertx);
		}
		
		((AbstractSession)pSession).putObject(ijoVertx);
	}

	/**
	 * {@inheritDoc}
	 */
	public void sessionDestroyed(ISession pSession)
	{
	}
	
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	// User-defined methods
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~	
	
	/**
	 * Gets the current Vertx instance.
	 * 
	 * @return the instance
	 */
	public Vertx getVertx()
	{
		return vertx;
	}
	
	/**
	 * Gets the current {@link org.vertx.java.core.http.HttpServer}.
	 * 
	 * @return the server instance
	 */
	public NetServer getNetServer()
	{
		return srvVertx; 
	}
	
	/**
	 * Starts the server to listen on the configured port.
	 */
	public void start()
	{
		if (vertx == null)
		{
			if (sClusterHost != null)
			{
				//clustered
				if (iClusterPort > 0)
				{
					vertx = Vertx.newVertx(iClusterPort, sClusterHost);
				}
				else
				{
					vertx = Vertx.newVertx(sClusterHost);
				}
			}
			else
			{
				//not clustered
				vertx = Vertx.newVertx();
			}
		}
		
		EventBusMapper mapper = new EventBusMapper(srvJVx);
		mapper.register(vertx.eventBus());
		
		srvVertx = vertx.createNetServer();
		
		srvVertx.connectHandler(new Handler<NetSocket>()
		{
			public void handle(NetSocket pSocket)
			{
		    	pSocket.dataHandler(new DataHandler(srvJVx, pSocket));
			}
		}).listen(iPort);
	}
	
	/**
	 * Sets the http server port.
	 * 
	 * @param pPort the port number
	 */
	public void setPort(int pPort)
	{
		iPort = pPort;
	}
	
	/**
	 * Gets the http server port.
	 * 
	 * @return the port number
	 */
	public int getPort()
	{
		return iPort;
	}

	/**
	 * Sets the hostname for clustering.
	 * 
	 * @param pHost the hostname or ip
	 */
	public void setClusterHost(String pHost)
	{
		sClusterHost = pHost;
	}
	
	/**
	 * Gets the cluster hostname.
	 * 
	 * @return the hostname or ip
	 */
	public String getClusterHost()
	{
		return sClusterHost;
	}
	
	/**
	 * Sets the port for clustering.
	 * 
	 * @param pPort the port number
	 */
	public void setClusterPort(int pPort)
	{
		iClusterPort = pPort;
	}
	
	/**
	 * Gets the cluster port.
	 * 
	 * @return the port number
	 */
	public int getClusterPort()
	{
		return iClusterPort;
	}
	
    //****************************************************************
    // Subclass definition
    //****************************************************************

	/**
	 * The <code>DataHandler</code> reads available data from the socket and forwards requests to
	 * the JVx server. The response from JVx will be written to te socket as client response.
	 * 
	 * @author Ren� Jahn
	 */
	private static final class DataHandler implements Handler<Buffer>
	{
		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		// Class members
		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

		/** the received data from the client (via socket). */
		private ByteArrayOutputStream baosReceived;

		/** the stream for the client response. */
		private ByteArrayOutputStream baosResponse;
		
		/** the stream for the JVx request (contains received data without the end frame). */
		private ByteArrayInputStream baisRequest;
		
		/** the JVx server. */
		private Server server;
		
		/** the socket. */
		private NetSocket socket;
		
		/** temporary read cache. */ 
		private byte[] byData;

		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		// Initialization
		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

		/**
		 * Creates a new instance of <code>DataHandler</code>.
		 * 
		 * @param pServer the JVx server
		 * @param pSocket the socket
		 */
		private DataHandler(Server pServer, NetSocket pSocket)
		{
			server = pServer;
			socket = pSocket;
		}

		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		// Interface implementation
		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

		/**
		 * {@inheritDoc}
		 */
		public void handle(Buffer pEvent)
		{
			try
			{
				if (baosReceived == null)
				{
					baosReceived = new ByteArrayOutputStream();
				}
				
				baosReceived.write(pEvent.getBytes());
				
				byData = baosReceived.toByteArray();
				
				//request end is marked with: 0x00 0x00 0xFF 0xFF
				if (byData.length >= 4 
					&& byData[byData.length - 4] == 0x00 
					&& byData[byData.length - 3] == 0x00 
					&& (byData[byData.length - 2] & 255) == 0xFF 
					&& (byData[byData.length - 1] & 255) == 0xFF)
				{
					server.process(new IRequest()
					{
						public Object getProperty(String pKey)
						{
							return null;
						}
						
						public Hashtable<String, Object> getProperties()
						{
							return null;
						}
						
						public InputStream getInputStream() throws IOException
						{
							if (baisRequest == null)
							{
								//remove request end bytes
								byte[] byInput = new byte[byData.length - 4];
								
								System.arraycopy(byData, 0, byInput, 0, byInput.length);
								
								byData = null;
								
								baisRequest = new ByteArrayInputStream(byInput);
							}
							
							return baisRequest;
						}
						
						public void close()
						{
							baosReceived = null;
							baisRequest = null;
						}
					}, 
					new IResponse()
					{
						public void setProperty(String pKey, Object pValue)
						{
						}
						
						public OutputStream getOutputStream() throws IOException
						{
							if (baosResponse == null)
							{
								baosResponse = new ByteArrayOutputStream();
							}
							
							return baosResponse;
						}
						
						public void close()
						{
							Buffer buffer = new Buffer(baosResponse.toByteArray()); 
							buffer.appendBytes(new byte[] {0x00, 0x00, (byte)0xFF, (byte)0xFF});

							socket.write(buffer);

							baosResponse = null;
						}
					});
				}
			}
			catch (Exception e)
			{
				//if stream contains data: server wrote exception via protocol
				if (baosReceived.size() == 0)
				{
					socket.write(new Buffer(new byte[] {0x00, 0x00, (byte)0xFF, (byte)0xFF}));
					
					throw new RuntimeException(e);
				}
			}
		}
		
	}	// DataHandler
	
}	// NetSocketServer
