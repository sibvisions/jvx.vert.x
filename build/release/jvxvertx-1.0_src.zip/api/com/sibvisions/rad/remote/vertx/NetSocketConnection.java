/*
 * Copyright 2012 SIB Visions GmbH
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 *
 *
 * History
 *
 * 29.12.2012 - [JR] - creation
 * 24.01.2012 - [JR] - close "old" socket otherwise events from old sockets will call notify()
 */
package com.sibvisions.rad.remote.vertx;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ConnectException;

import javax.rad.remote.ConnectionInfo;

import org.vertx.java.core.Handler;
import org.vertx.java.core.Vertx;
import org.vertx.java.core.buffer.Buffer;
import org.vertx.java.core.net.NetClient;
import org.vertx.java.core.net.NetSocket;

import com.sibvisions.rad.remote.AbstractSerializedConnection;
import com.sibvisions.rad.remote.ISerializer;

/**
 * The <code>NetSocketConnection</code> is an {@link javax.rad.remote.IConnection} that uses a {@link NetSocket} for
 * the communication to a {@link org.vertx.java.core.net.NetServer}.
 * 
 * @author Ren� Jahn
 */
public class NetSocketConnection extends AbstractSerializedConnection
{
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	// Class members
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	/** the command end sequence. */
	private static final byte[] COMMAND_END = new byte[] {0x00, 0x00, (byte)0xFF, (byte)0xFF};

	/** the send buffer. */
	private ByteArrayOutputStream baosSend;
	
	/** the receive data buffer. */
	private ByteArrayOutputStream baosReceive;
	
	/** A vertx instance. */
	private Vertx vertx;
	
	/** the client. */
	private NetClient client;
	
	/** the established socket connection. */
	private NetSocket socket;

	/** the "command end" mark. */
	private Buffer bufEndMark = new Buffer(COMMAND_END);
	
	/** the server hostname or ip. */
	private String sHost;
	
	/** the server port. */
	private int iPort = 8888;
	
	/** the sync object for wait/notify. */
	private final Object sync = new Object();
	
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	// Initialization
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	/**
	 * Creates a new instance of <code>NetSocketConnection</code> that connects
	 * to the given server.
	 * 
	 * @param pHost the server hostname or ip
	 */
	public NetSocketConnection(String pHost)
	{
		//default
		this(null, pHost, -1);
	}
	
	/**
	 * Creates a new instance of <code>NetSocketConnection</code> that connects
	 * to the given server.
	 * 
	 * @param pHost the server hostname or ip
	 * @param pPort the server port
	 */
	public NetSocketConnection(String pHost, int pPort)
	{
		this(null, pHost, pPort);
	}

	/**
	 * Creates a new instance of <code>NetSocketConnection</code> that connects
	 * to the given server.
	 * 
	 * @param pVertx the vert.x instance or <code>null</code> to create a new (standalone) instance
	 * @param pHost the server hostname or ip
	 * @param pPort the server port
	 */
	public NetSocketConnection(Vertx pVertx, String pHost, int pPort)
	{
		super((ISerializer)null);
		
		sHost = pHost;
		
		if (pPort > 0)
		{
			iPort = pPort;
		}
		
		if (pVertx == null)
		{
			vertx = Vertx.newVertx();
		}
		else
		{
			vertx = pVertx;
		}
		
		client = vertx.createNetClient();
		client.setReconnectAttempts(3);
		client.setReconnectInterval(1000);
	}
	
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	// Overwritten methods
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public void open(ConnectionInfo pConnectionInfo) throws Throwable
	{
		closeSocket();
		
		client.connect(iPort, sHost, new Handler<NetSocket>()
		{
			public void handle(NetSocket pSocket)
			{
				pSocket.dataHandler(new Handler<Buffer>()
				{
					public void handle(Buffer pBuffer)
					{
						try
						{
							baosReceive.write(pBuffer.getBytes());

							byte[] byData = baosReceive.toByteArray();
												
							if (byData.length >= COMMAND_END.length 
								&& byData[byData.length - 4] == COMMAND_END[0]
								&& byData[byData.length - 3] == COMMAND_END[1]
								&& byData[byData.length - 2] == COMMAND_END[2]
								&& byData[byData.length - 1] == COMMAND_END[3])
							{
								synchronized(sync)
								{
									sync.notify();
								}
							}
						}
						catch (Exception e)
						{
							throw new RuntimeException(e);
						}
					}
				});
				
				pSocket.exceptionHandler(new Handler<Exception>()
				{
					public void handle(Exception pException)
					{
						synchronized(sync)
						{
							sync.notify();
						}
					}
				});
				
				pSocket.endHandler(new Handler<Void>()
				{
					public void handle(Void pParam)
					{
						synchronized(sync)
						{
							sync.notify();
						}
					}
			
				});
				
				socket = pSocket;
				
				synchronized(sync)
				{
					sync.notify();
				}
			}
		});

		client.exceptionHandler(new Handler<Exception>()
		{
			public void handle(Exception pException)
			{
				if (socket == null)
				{
					synchronized(sync)
					{
						sync.notify();
					}
				}
			}
		});
		
		synchronized(sync)
		{
			if (socket == null)
			{
				try
				{
					sync.wait(15000);
				}
				catch (Exception e)
				{
					//nothing to be done
				}
			}
		}
		
		if (socket == null)
		{
			throw new ConnectException("Can't establish connection!"); 
		}
		
		super.open(pConnectionInfo);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void close(ConnectionInfo pConnectionInfo) throws Throwable
	{
		super.close(pConnectionInfo);
		
		closeSocket();

		client.close();
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public OutputStream getOutputStream(ConnectionInfo pConnectionInfo) throws Throwable
	{
		baosSend = new ByteArrayOutputStream();
		
		return baosSend;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public InputStream getInputStream(ConnectionInfo pConnectionInfo) throws Throwable
	{
		baosReceive = new ByteArrayOutputStream();

		synchronized(sync)
		{
			//in SYNC block, otherwise it's possible that notify will be called before wait was called
			//this would start an endless wait
			Buffer buffer = new Buffer(baosSend.toByteArray());
			buffer.appendBuffer(bufEndMark);
			
			socket.write(buffer);
			
			try
			{
				sync.wait();
			}
			catch (Exception e)
			{
				//nothing to be done
			}
		}
		
		byte[] byData = baosReceive.toByteArray();
		byte[] byInput = new byte[byData.length - COMMAND_END.length];
		
		System.arraycopy(byData, 0, byInput, 0, byInput.length);

		baosReceive = null;
		byData = null;
		
		return new ByteArrayInputStream(byInput);
	}

	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	// User-defined methods
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~	

	/**
	 * Close the "old" socket.
	 */
	private void closeSocket()
	{
		if (socket != null)
		{
			socket.exceptionHandler(null);
			socket.endHandler(null);
			socket.dataHandler(null);
			
			socket.close();
			socket = null;
		}
	}
	
	/**
	 * Gets the current Vertx instance.
	 * 
	 * @return the instance
	 */
	public Vertx getVertx()
	{
		return vertx;
	}
	
}	// NetSocketConnection
